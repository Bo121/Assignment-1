/**
 * Class: CMSC203 
 *  Program: Assignment #1
 *  Instructor: Dr. Grinberg
 * Description: WiFi Diagnose
   A program that requires you to use functions to calculate the volume of a box and the    volume of a Sphere.
 * Due: 02/14/2022 
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Shengquan Yang
*/


import java.util.Scanner;

public class Test 
{
	public static void main(String[] args)
	{
		
		Scanner keyboard = new Scanner(System.in);
		
		//Prompt the user to enter yes or no towards the questions
		System.out.println("If you have a problem with internet connectivity, this WiFi Diagnosis might work.\n");
		System.out.println("First step: reboot your computer");
		System.out.println("Now are you able to connect with the internet? (yes or no)");
		
		String input = keyboard.next();
		
		//If the user enters yes, the program will end
		if (input.equals("yes"))
		{
			return;
		}
		
		//If the user enters no, the program will continue
		else if(input.equals("no"))
		{
			//Prompt the user to enter yes or no towards the questions
			System.out.println("Second step: reboot your router");
			System.out.println("Now are you able to connect with the internet? (yes or no)");
			
			String input_2 = keyboard.next();
			
			//If the user enters yes, the program will end
			if (input_2.equals("yes"))
			{
				return;
			}
			
			//If the user enters no, the program will continue
			else if(input_2.equals("no"))
			{
				//Prompt the user to enter yes or no towards the questions
				System.out.println("Third step: make sure the cables to your router are plugged in firmly and your router is getting power");	
				System.out.println("Now are you able to connect with the internet? (yes or no)");
				
				String input_3 = keyboard.next();
				
				//If the user enters yes, the program will end
				if (input_3.equals("yes"))
				{
					return;
				}
				
				//If the user enters no, the program will continue
				else if(input_3.equals("no"))
				{
					//Prompt the user to enter yes or no towards the questions
					System.out.println("Fourth step: move the computer closer to the router and try to connect");
					System.out.println("Now are you able to connect with the internet? (yes or no)");
					
					String input_4 = keyboard.next();
					
					//If the user enters yes, the program will end
					if (input_4.equals("yes"))
					{
						return;
					}
					
					//If the user enters no, the program will continue
					else if(input_4.equals("no"))
					{
						System.out.println("Fifth step: Contact your ISP");
						System.out.println("Make sure your ISP is hooked up to your router.");
						return;
					}
				}
			}
		}
	}
}
